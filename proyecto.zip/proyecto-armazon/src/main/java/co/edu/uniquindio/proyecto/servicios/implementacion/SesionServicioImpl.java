package co.edu.uniquindio.proyecto.servicios.implementacion;

import co.edu.uniquindio.proyecto.dto.SesionDTO;
import co.edu.uniquindio.proyecto.dto.TokenDTO;
import co.edu.uniquindio.proyecto.servicios.interfaces.SesionServicio;

public class SesionServicioImpl implements SesionServicio {
    @Override
    public TokenDTO login(SesionDTO sesionDTO) {
        return null;
    }

    @Override
    public void logout(int codigoUsuario) {

    }
}
