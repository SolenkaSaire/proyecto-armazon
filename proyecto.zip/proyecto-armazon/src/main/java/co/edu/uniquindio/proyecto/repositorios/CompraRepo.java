package co.edu.uniquindio.proyecto.repositorios;

public interface CompraRepo {
}
