package co.edu.uniquindio.proyecto.servicios.implementacion;

import co.edu.uniquindio.proyecto.dto.EmailDTO;
import co.edu.uniquindio.proyecto.servicios.interfaces.EmailServicio;

public class EmailImpl implements EmailServicio {
    @Override
    public String enviarEmail(EmailDTO emailDTO) {
        return null;
    }
}
