package co.edu.uniquindio.proyecto.jakarta.persistence;

//@Entity
public enum Estado {
    APROBADO, NO_APROBADO;
}