package co.edu.uniquindio.proyecto.repositorios;

import org.springframework.stereotype.Repository;

@Repository
public interface DetalleCompraRepo {
}
